import 'package:elearing/views/auth/sigin.dart';
import 'package:elearing/views/auth/sigup.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../utlis/color.dart';
import '../../widget/coustoumbutton.dart';

class SelectLoginSignUp extends StatelessWidget {
  const SelectLoginSignUp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Column(
                children: [
                  Expanded(
                    child: Image.asset(
                      "images/appthemeimage1.png",
                      fit: BoxFit.fill, // Cover the width completely
                    ),
                  ),
                  SizedBox(height: 30),
                  Spacer(),
                  Column(
                    children: [
                      CustomButton(
                        color: AppColors.whitecolor,
                        text: "Sign In",
                        textStyle: AppStyles.purple16,
                        onTap: () {
                          Get.to(SigIn());
                        },
                      ),
                      SizedBox(height: 20),
                      CustomButton(
                        color: AppColors.purplecolor,
                        text: "Sign up",
                        textStyle: AppStyles.white16,
                        onTap: () {
                          Get.to(Sigup());
                        },
                      ),
                    ],
                  ),
                  Spacer(),
                  Expanded(
                    child: Image.asset(
                      "images/appthemeimage.png",
                      fit: BoxFit.fill, // Cover the width completely
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
