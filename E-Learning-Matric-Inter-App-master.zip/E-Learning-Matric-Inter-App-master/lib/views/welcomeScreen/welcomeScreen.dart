import 'package:elearing/utlis/color.dart';
import 'package:elearing/views/auth/selectloginsigup.dart';
import 'package:elearing/widget/reuseabletext.dart';
import 'package:flutter/material.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  @override
  void initState() {
    super.initState();
    // Add a delay of 3 seconds before navigating to the home page
    Future.delayed(Duration(seconds: 3), () {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) =>
              SelectLoginSignUp(), // Replace HomeScreen with your actual home page widget
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          // mainAxisAlignment: MainAxisAlignment.center,
          // crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  // crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Image.asset(
                      "images/appthemeimage1.png",
                      fit: BoxFit.fitWidth,
                    ),
                    Image.asset(
                      "images/logo.png",
                      width: 250,
                      height: 250,
                    ),
                    CircularProgressIndicator(),
                    AppText(
                      text: 'EDUFLEX',
                      style: AppStyles.lightpurple20,
                    ),
                    // Other widgets in the body
                  ],
                ),
              ),
            ),
            // Image at the bottom
            Image.asset(
              "images/appthemeimage.png",
              fit: BoxFit.fitWidth,
            ),
          ],
        ),
      ),
    );
  }
}
