import 'package:elearing/navigation_bar/navigation_bar.dart';
import 'package:elearing/utlis/color.dart';
import 'package:elearing/views/welcomeScreen/welcomeScreen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get_navigation/get_navigation.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      appId: '1:251014960618:android:2bb7067bfb3293dd080e93',
      apiKey: 'AIzaSyCmU26sU9rHn3ytTthV6oikmMR927Sl7Jo',
      messagingSenderId: '251014960618', projectId:'eduflex-38bf5',
    ),
  );

  runApp( MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: "elearning",
      theme: ThemeData(
        colorScheme: const ColorScheme.light(
          primary: AppColors.blackcolor,
        ),
        scaffoldBackgroundColor: AppColors.scaffoldcolor,
      ),
      // home: const MaterialYou(),
      home: const WelcomeScreen(),
    );
  }
}

// import 'package:elearing/utlis/color.dart';
// import 'package:elearing/views/welcomeScreen/welcomeScreen.dart';
// import 'package:firebase_core/firebase_core.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get_navigation/get_navigation.dart';
// void main()async {
//   WidgetsFlutterBinding.ensureInitialized();
//   await Firebase.initializeApp(
//   );

//   runApp( MyApp());
// }

// class MyApp extends StatelessWidget {
//   final Future<FirebaseApp> initialization = Firebase.initializeApp();
//   MyApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return GetMaterialApp(
//       debugShowCheckedModeBanner: false,
//       title: 'Flutter Demo',
//       theme: ThemeData(
//           colorScheme: ColorScheme.light(
//             primary: AppColors.blackcolor,
//           ),
//           scaffoldBackgroundColor: AppColors.scaffoldcolor
//       ),
//       home: WelcomeScreen(),
//     );
//   }
// }

