import 'package:elearing/utlis/color.dart';
import 'package:elearing/widget/reuseabletext.dart';
import 'package:flutter/material.dart';


class CustomCategoryContainer extends StatelessWidget {
  final String imagePath;
  final String categoryName;
  final VoidCallback? onTap;

  CustomCategoryContainer({
    required this.imagePath,
    required this.categoryName,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 120,
        width: 130,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: AppColors.lightpurple,
        ),
        child: Column(
          children: [
            Container(
              height: 80,
              width: 80,
              child: Image.asset(imagePath),color: Colors.white,
            ),
            SizedBox(height: 5),
            AppText(
              text: categoryName,
              style: AppStyles.white13,
            ),
          ],
        ),
      ),
    );
  }
}
