import 'package:elearing/widget/reuseabletext.dart';
import 'package:flutter/material.dart';
import '../utlis/color.dart';


class CustomHeaderStack extends StatelessWidget {
  final String title;
  final String subTitle;

  CustomHeaderStack({
    required this.title,
    required this.subTitle,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Column(
          children: [
            Image.asset("images/apptheme3.png"),
          ],
        ),
        Padding(
          padding: const EdgeInsets.only(left: 20, top: 50),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  GestureDetector(
                    onTap:(){
                      Navigator.of(context).pop();
                    },
                    child: Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: AppColors.purplecolor,
                      ),
                      child: Icon(Icons.arrow_back, color: AppColors.whitecolor),
                    ),
                  ),
                  SizedBox(width: 55),
                  AppText(
                    text: title,
                    style: AppStyles.white24,
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(left: 80, top: 10),
                child: AppText(
                  text: subTitle,
                  style: AppStyles.white16,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
