package com.example.elearing

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
